import PageWrapper from "@/components/PageWrapper"
import { StockStoreAdvanceSearchParams, StockStoreLess } from "@/services/sale/data"
import { formatDate } from "@/pages/utils"
import { ExportOutlined, FileOutlined, PlusOutlined } from "@ant-design/icons"
import { Tag } from "antd"
import { uniqueId } from "lodash"
import { useAccess, useQuery } from "@umijs/max"
import { Model } from "./model"
import { TableViewSearchParams } from "@/components/DataCrud/TableView"
import { useRef, useState } from "react"
import StockStoreDetail from "./Detail"
import { ActionType } from "@ant-design/pro-components"
import StockStoreForm from "./components/StockStoreForm"
interface Props {
}
const StoreMainPage: React.FC<Props> = () => {
    const access = useAccess();
    const { state, actions, modals } = Model();
    const actionRef = useRef<ActionType>();
    const [filter, setFilter] = useState<TableViewSearchParams<StockStoreAdvanceSearchParams>>({
        criteria: { advanceSearch: { status: 'ALL' } }
    })
    const { data, isFetching, refetch } = useQuery(['fetch-customer-list', filter], () => actions.loadListItem(
        filter.criteria,
        filter.pagination,
    ), {
        refetchOnWindowFocus: false
    });
    return <>
        <PageWrapper<StockStoreLess, StockStoreAdvanceSearchParams, {}>
            tabRender={item => [
                {
                    action: "add",
                    tabIcon: <FileOutlined />,
                    tabLabel: 'New Stock',
                    tabKey:item?.id,
                    panel: ({ onUpdateTab,onCloseTab, key }) => <StockStoreForm
                        type="new"
                        onView={(it) => onUpdateTab?.("view", it, undefined, key)}
                        onBack={onCloseTab}
                    />
                },
                {
                    action: 'copy',
                    tabLabel: item?.name ? `Copy (#${item.name})` : 'Copy',
                    tabKey: `copy-${item?.id}-${uniqueId('copy')}`,
                },
                {
                    action: 'view',
                    value: item?.name || "n/a",
                    tabLabel: item?.name || 'Draft',
                    tabKey:item?.id,
                    panel: ({ onUpdateTab,onAddTab, onCloseTab, key }) => <StockStoreDetail
                        id={item?.id}
                        onEdit={() => onUpdateTab?.('edit', undefined, undefined, key)}
                        onAdd={() => onAddTab?.('add', undefined, key)}
                    />
                },
                {
                    action: 'edit',
                    value: item?.name || "n/a",
                    tabLabel: item?.name || 'Draft',
                    tabKey:item?.id,
                    panel: ({ onUpdateTab, onCloseTab, key }) => <StockStoreForm
                        id={item?.id}
                        type="edit"
                        onView={(it) => onUpdateTab?.("view", it, undefined, key)}
                        onBack={()=> {
                            onUpdateTab?.("view", undefined, undefined, key)  
                            refetch()
                        }}
                    />
                }
            ]}
            listView={{
                type: "Table",
                title: "Store List",
                onFilter: (params, page, sort) => {
                    setFilter(v => ({
                        ...v,
                        criteria: {
                            searchValue: params?.searchValue,
                            advanceSearch: {
                                status: params?.status || "ALL"
                            },
                            sort: sort
                        },
                        pagination: { ...page }
                    }))
                },
                actionButtons: [
                    {
                        icon: <PlusOutlined />,
                        type: "link",
                        addNewTab: true
                    },
                ],
                statuses: [
                    { option: { label: "All", value: "ALL", default: true } },
                    { option: { label: "Open", value: "open" } },
                    { option: { label: "Closed", value: "closed" } },
                ],
                onRefresh: refetch,
                props: {
                    dataSource: data?.items,
                    actionRef: actionRef,
                    loading: isFetching,
                    pagination: {
                        total: data?.total,
                    },
                    columns: [
                        {
                            title: 'Store Name',
                            dataIndex: 'name',
                            actionProps: (item) => ({
                                type: 'view',
                                label: item.name || 'n/a',
                                actionButtons: [
                                    { icon: <ExportOutlined />, type: 'link', size: 'small', onClick: () => window.open(`/external/sale/store/detail/${item.id}`, '_blank')?.focus() }
                                ]
                            }),
                        },
                        {
                            title: 'Store Type',
                            render: (_, r) => {
                                return r.members?.find((it) => it.isRequester)?.role;
                            },
                        },
                        {
                            title: 'Vehicle',
                            render: (_, r) => {
                                return r.vehicle?.plateNumber;
                            },
                        },
                        {
                            title: 'Created Date',
                            render: (_, r) => {
                                return formatDate(r.createdDate);
                            },
                        },
                        {
                            title: 'Status',
                            align: 'center',
                            render: (_, r) => {
                                const color =
                                    r.status === 'pending'
                                        ? 'default'
                                        :r.status === 'Open'
                                            ? 'success'
                                            : r.status === 'canceled' || r.status === 'Closed'
                                                ? 'magenta'
                                                : 'warning';
                                return (
                                    <span>
                                        <Tag color={color}>{r.status}</Tag>
                                    </span>
                                );
                            },
                        },
                        {
                            title: 'Description',
                            dataIndex: 'description',
                        },
                    ]
                }
            }}
        />
    </>

}

export default StoreMainPage